const express = require('express');
const mongoose = require('mongoose');
const multer = require('multer');
const cors = require('cors');
const bodyParser = require("body-parser");
const person=require('./personModel')
const port = process.env.PORT || 5000;

const app = express();
app.use(cors());
app.use(bodyParser.json());

mongoose.connect("mongodb://127.0.0.1:27017/vivah")

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

app.post('/upload', upload.single('image'), async (req, res) => {
    try {
      const { fname,mname,lname,gender,mobilenumber,email,password,dob,age,nri,height,cast,maritialstatus,
                fathername,mothername,eductaion,occupation,income,address,hobbies,physicaldisability} = req.body;
      const image = req.file.buffer;
  
      const newPerson = new person({
        fname,mname,lname,gender,mobilenumber,email,password,dob,age,nri,height,cast,maritialstatus,
        fathername,mothername,eductaion,occupation,income,address,hobbies,physicaldisability,
        image,
      });
  
      await newPerson.save();
      res.status(201).json({ message: 'User created successfully' });
    } catch (error) {
      console.error('Error creating user', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get('/user', async (req, res) => {
    try {
      const users = await person.find({});
      
      // Convert the binary image data to Base64 for each user
      const usersWithBase64Image = users.map(user => ({
        ...user.toObject(),
        image: user.image.toString('base64'),
      }));
  
      res.status(200).json(usersWithBase64Image);
    } catch (error) {
      console.error('Error retrieving users', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.post("/user/login", async (req, res) => {
    try {
      const { email, password } = req.body;
  
      // Find the user by email and password (you should enhance this for security)
      const user = await person.findOne({ email, password });
  
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
  
      // Send the user details
      res.status(200).json(user);
    } catch (error) {
      console.error("Error logging in:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  app.post("/add-to-wishlist/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const { personId } = req.body;
  
      // Find the logged-in user by their ID
      const user = await person.findById(userId);
  
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
  
      // Find the person you want to add to the wishlist
      const personToAdd = await Person.findById(personId);
  
      if (!personToAdd) {
        return res.status(404).json({ error: "Person not found" });
      }
  
      // Add the person to the wishlist array
      user.wishlist.push(personToAdd);
  
      // Save the updated user document
      await user.save();
  
      return res.status(200).json({ message: "Person added to wishlist" });
    } catch (error) {
      console.error("Error adding person to wishlist", error);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

app.listen(port, () => {
console.log(`Server is running on port ${port}`);
  });

